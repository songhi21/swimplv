@extends('layouts.admin')
@vite(['resources/sass/app.scss', 'resources/js/app.js'])

@section('content')
{{-- <div class="container"> --}}
    {{-- <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div> --}}
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            {{-- banner 1 --}}
        <div class="col-12 grid-margin stretch-card">
            <div class="card corona-gradient-card">
            <div class="card-body py-0 px-0 px-sm-3">
                <div class="row align-items-center">
                <div class="col-4 col-sm-3 col-xl-2">
                    <img src="assets/images/SWim logo 2.png" class="gradient-corona-img img-fluid" alt="">
                </div>
                <div class="col-5 col-sm-7 col-xl-8 p-0">
                    <h4 class="mb-1 mb-sm-0 textcolorwhite">Welcome to Swim Project 3 Central Hub</h4>
                    <p class="mb-0 font-weight-normal d-none d-sm-block textcolorwhite">Centralize Data structure</p>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
        
        <div class="row">
        <div class="col-xl-12 col-sm-12 grid-margin stretch-card">
            <div class="card">
            <div class="card-body">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img class="d-block cover"  src="image/1.JPG">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block cover"  src="image/2 .JPG" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block cover" src="image/3.JPG" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
            </div>
            </div>
        </div>
        <div class="col-xl-6 col-sm-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body card-description">
                    <p>Program Leader/Sex: Dr. Orlando F. Balderama/Male</p>
                    <p> Project Leader/Sex: Dr. Rafael J. Padre/Male</p>
                    <p>  Agency: Isabela State University</p>
                    <p> Address/Telephone/Fax/Email: San Fabian, Echague, Isabela/ rjpadre@isu.edu.ph</p>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-sm-6 grid-margin stretch-card">
            <div class="card">
            <div class="card-body card-description">
                <p> COOPERATING AGENCY/IES: LGU Cauayan City</p>
                <p> SITE(S) OF IMPLEMENTATION (Municipality / District / Province / Region)</p>
                <p>    Base Station: Cauayan City , Isabela, Region 2</p>
                <p>Other Site(s) of Implementation: None</p>
                    
            </div>
            </div>
        </div>
        </div>
        <div class="row">
        <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
            <div class="card-body">
                <img src="assets/images/SWim logo 2.png" width="100%">
            </div>
            </div>
        </div>
        <div class="col-md-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body card-description">
                    {{-- content inside --}}
                    <h1> Dashboard  </h1>
                    <p >Cauayan City in Isabela is one of the country’s premier agro-industrial hubs and also one of the Philippines’ first smart cities (Smart Communications, 2019), recognized by the Department of Science and Technology (DOST) for  its  innovation  in  adopting  science and technology development (Alvarez, M.S. et.al., 2020). Since urban areas, such as Cauayan City, are the hub of economic development and activity, there is a tendency for people and businesses to converge which results in higher water demand.
                        At present, Cauayan has a total  fifteen (15) water pumping stations and eight (8) elevated water tanks serving only 12,067 households (29%) out of 30,207 households (71%).   The  combined distribution efficiency of these water infrastructures under  the management and supervision  of the Cauayan City Water District (CCWD) is only  87% which is accounted from the 9,229.63 m3 of metered water out of the distributed water of 10,518.13 m3 daily or with a combined distribution losses of   10% which is  1282.50m3 losses per day, ( Alvarez  M. S. et.al., 2020).  The said study  suggests  the  necessity to introduce new and innovative water management technologies and systems adapted to climate change to addressed the need of the city like; improve the  performance of the  existing water infrastructure systems,  lack of management tool  for  more efficient delivery of water services, limited service coverage of the water district due to limited water resource and depletion and contamination of aquifers and other water sources since shallow aquifer are mainly  utilized. Hence, a  GIS-based decision support tool in managing urban water infrastructure with storm water invention is a proposed solution  to address the need of the city.
                        </p>
                    <p>In order to maximize and properly utilize  water  infrastructure, the integration of decision support systems (DSS) and geographic information systems (GIS) is needed to provide the necessary spatial database for transforming a simple spatial query and visualization tool into a powerful analytical and spatially distributed modeling tool (Satti, S.R., et.al. 2004). Reitsma (1996) define a DSS for water resources applications as computer-based systems which integrate state information, dynamic or process information, and plan evaluation tools into a single software implementation.  One of the tools that can be used as DSS is the MIKE Operation. It is a complete GIS-integrated modelling tool that enables users to make sound decisions and create future concepts for urban stormwater systems  - concepts that are cost-effective as well as resilient to change <a href="https://www.mikepoweredbydhi.com">https://www.mikepoweredbydhi.com</a>. </p>
                </div>
            </div>
        </div>
        </div>








{{-- </div> --}}
@endsection
