
@extends('layouts.navhome')
@section('content')

  <input checked='checked' id='rad1' name='rad' type='radio'>
  <input id='rad2' name='rad' type='radio'>
  <input id='rad3' name='rad' type='radio'>
  <input id='rad4' name='rad' type='radio'>
  <input id='rad5' name='rad' type='radio' >
  <input id='rad6' name='rad' type='radio' >
  <div class='btn'></div>
  <div id='wrap'>
    <input type='checkbox'>
    <div class='slide'>
      <div class='label'></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
      </div>
      <label>classification</label>
      <p class='classifications'>
        <span> Interactive maps: </span>
        <span>Mapping APIs: </span>
        <span>Installed Sensors: </span>
      </p>
    </div>
    <div class='slide'>
      <div class='label'></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
      </div>
      <label>classification</label>
      <p class='classifications'>
        <span> Model: </span>
        <span>Measuring range: </span>
        <span>Working pressure: </span>
        <span>Display: </span>
        <span>Communication interface: </span>
      </p>
    </div>
    <div class='slide'>
      <div class='label'></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
        <label>classification</label>
      </div>
      <p class='classifications'>
        <span> Model: </span>

        <span>Output signal: </span>

        <span>Measurementspan: </span>

        <span>Mounting bracket: </span>
      </p>
    </div>
    <div class='slide'>
      <div class='label'></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
        <label>classification</label>
      </div>
      <p class='classifications'>
        <span> Model: </span>

        <span>MeasurementConfig: </span>

        <span>Com: </span>

        <span>Power Supply: </span>
      </p>
    </div>
    <div class='slide' >
      <div class='label'></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
      </div>
      <label>classification</label>
      <p class='classifications'>
        <span> Special Features: </span>
        <span>Function: </span>
        <span>Style: </span>
      </p>
    </div>
    <div class='slide order-red'>
      <div class='label '></div>
      <div class='search'></div>
      <div class='image'></div>
      <div class='content'>
        <h1></h1>
        <p>
          <span>Definition:</span>
        </p>
      </div>
      <p class='classifications'>
        <span> MIKE Workbench: </span>
      </p>
    </div>
    <div class='jar'></div>
    <div class='outer'>
      <div class='box'></div>
    </div>
  </div>
  <div class='panels'></div>
  <div class='panels'></div>
  <div class='panels'></div>
  <div class='panels'></div>
  <div class='panels'></div>
  <div class='panels'></div>
  
@endsection