<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head class="border-red">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'SWIMP3') }}</title>
    {{-- <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
    crossorigin=""/> --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/leaftlet.css" />
    <link rel="stylesheet" href="../css/L.Control.Layers.Tree.css" />
       <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="../js/leaflet.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="../css/esri-leaflet-geocoder.css">
    <script src="../js/esri-leaflet.js"></script>

    <script src="../js/esri-leaflet-geocoder.js"></script>
    <link href="../css/btnnavchangecss.css" rel="stylesheet">
    <link href="../css/maps.css" rel="stylesheet" >

   
 


</head>
    <body >
        <div id="loadingIndicator">Loading...</div>
        {{-- content --}}
        
        <div class="container overlay">
            <br>
            <nav class="navbar navbar-expand-lg navbar-dark bgnav">
                <div class="container image_wrapper">
                    <a class="navbar-brand" href="{{ config('variable.url') }}/" style="font-weight:bold!important">
                        <img src="../image/p3.png" width="80" height="60" alt="" >
                        <span style="font-weight: bold; color:rgb(17, 17, 17);font-family: Lucida Handwriting;">Swim Project 3 </span>
                        <span style="font-weight: bold; color:rgb(17, 17, 17)">| </span>
                    </a>
                    
                    <span style="font-size: 100%;  color:rgb(17, 17, 17); ">  Storm Water Harvesting Facility Decision Support</span>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <!-- Left-aligned items -->
                    <ul class="navbar-nav me-auto">
                    
                    </ul>
                    <!-- Right-aligned items -->
                    <ul class="navbar-nav text-navconf">
                        <li class="nav-item">
                            <a aria-current="page" href="{{ config('variable.url') }}/" class="{{ Request::segment(1) == '' ? 'bn632-hover bn26' : null}}">Home</a>
                        </li>
                        <li class="nav-item">
                            <a  href="{{ config('variable.url') }}../about"  class="{{ Request::segment(1) == 'about' ? 'bn632-hover bn26' : null}}">About</a>
                        </li>
                        <li >
                            <li class="nav-item dropdown">
                                <a   role="button" class="bn632-hover bn26 nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" >Data</a>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="{{ config('variable.url') }}../maps" style="letter-spacing: 2px!important">Sensors</a></li>
                                    <li><a class="dropdown-item" href="{{ config('variable.url') }}../mapsoutput" style="letter-spacing: 2px!important">Maps</a></li>

                                </ul>
                              </li>
                        </li>
                        <li class="nav-item">
                            <a  href="{{ config('variable.url') }}../login">Login</a>
                    </ul>
                </div>
                </div>
            </nav>
        </div>
        @yield('content')
        <div class="container-scroller ">
            


            

            <script src="https:///ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
            <script src="../js/maps/L.KML.js"></script>
            <script src="../js/maps/spin.min.js" charset="utf-8"></script>
            <script src="../js/maps/leaflet.spin.min.js" charset="utf-8"></script>
            <script type="text/javascript" src="../js/L.Control.Layers.Tree.js"></script>
            
            <script type="text/javascript" src="../js/proj4.js"></script>
            

            <script type="text/javascript" src="../js/proj4leaflet.min.js"></script>

            <script type="text/javascript" src="../js/coord-projection.js"></script>
            {{-- <script src="https://unpkg.com/leaflet.kml"></script> --}}
            <script src='https://api.tiles.mapbox.com/mapbox.js/plugins/leaflet-omnivore/v0.3.1/leaflet-omnivore.min.js'></script>
            <script type="text/javascript" src="../assets/js/mapsoutput/result.js"></script>
            {{-- <script src="../assets/js/mapsoutput/shp.js"></script> --}}
            {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/shpjs/3.7.1/shapefile.js"></script> --}}
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.5.0/jszip.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/shpjs/3.6.2/shp.min.js"></script>
            <script src="../js/maps/leaflet.shpfile.js"></script>
            




            <script>
            
                    // display map view----------------------------
                        // const map = L.map('map').setView([16.95248, 121.76696], 21);


                        //Maplayer type --------------------------------------------
                        const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 18,
                                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                            });
                        const osmHOT = L.tileLayer('https://tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
                                maxZoom: 18,
                                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                            });
                        // const openTopoMap = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                        //     maxZoom: 19,
                        //     attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
                        // });
                        const world_imagry = L.tileLayer('http://server.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                            maxZoom: 17,
                            // attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                        });
                        const world_topo = L.tileLayer('https://services.arcgisonline.com/arcgis/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
                            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                            maxZoom: 17, 
                            zoomOffsetAllowance: 0.1, 
                            errorTileUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAA…AAAAAAAAAAAAAAAAA7waBAAABw08RwAAAAABJRU5ErkJggg==",
                            minZoom: 0, 
                            subdomains: Array(3),
                            zoomOffset: 0, tms: false, zoomReverse: false, detectRetina: false, crossOrigin: false, referrerPolicy: false, tileSize: 256, opacity: 1, updateWhenIdle: false, updateWhenZooming: true, updateInterval: 200, zIndex: 3, bounds: null, maxNativeZoom: undefined
                        });

                        //---------------------------------------------------------------------

                        const map = L.map('map2', {
                            center: [16.9, 121.8],
                            zoom: 11,
                            zoomControl: true,
                            layers: [world_imagry]
                        });
                        //----maplayer end----------------------------------
                        

   
                        
                        
                        //grouplayers-------------------------------------------------------
                        var basebaseLayers = {
                            "OpenStreetMap": tiles,
                            "OpenStreetMap.HOT": osmHOT,
                            "world_topo": world_topo,
                            // "openTopoMap" : openTopoMap,
                            "world_imagry" : world_imagry
                                
                            };

                        //kml file----------------------------------------------
                        var customLayer = L.geoJson(null, {
                            // http://leafletjs.com/reference.html#geojson-style
                            style: function(feature) {
                                return { color: '#696969' ,weight: '1' ,stroke: 'true', fillOpacity:'0' };
                            }
                        });
                        var customLayer2 = L.geoJson(null, {
                            // http://leafletjs.com/reference.html#geojson-style
                            style: function(feature) {
                                return { color: 'black' ,weight: '1' ,stroke: 'true', fillOpacity:'0' };
                            }
                        });
                        // maplayers kml--------------------------------------








                        // const Buildingkml = omnivore.kml('assets/kml/pssm/Building.kml', null, customLayer);
                        //buildings---------------------------------
                        const Buildingkml = omnivore.kml('../assets/kml/pssm/Building.kml');


                        const isabelakml = omnivore.kml('../assets/kml/pssm/Isabela.kml', null, customLayer);

                        const  cauayankml = omnivore.kml('../assets/kml/pssm/CauayanCityBoundary.kml', null, customLayer2).addTo(map);
                        // const  fiveyr = omnivore.kml('../assets/kml/fhm/fh5yr.kml', null, customLayer2);
                        var id = $('#hiddenId').val();

                        //image display----------------------------
                        // var imageUrl = '../image/mapsoutput/5yrr/Cauayan_FHM5YRRRP.png';
                        // var imageBounds = [[51.49, -0.14], [51.51, -0.06]];

                        // // Add the image overlay to the map
                        // L.imageOverlay(imageUrl, imageBounds).addTo(map);

                        // Optionally, you can fit the map to the bounds of the image
                        // map.fitBounds(imageBounds);
                        // Define color styles for different flood risk levels
                        // Define color styles for different flood risk levels
                            //image display----------------------------
                        var lowRiskStyle = { fillColor: '#ADD8E6', weight: 1, opacity: 1, color: 'white', fillOpacity: 0.7 };
                        var moderateRiskStyle = { fillColor: '#8FBC8F', weight: 1, opacity: 1, color: 'white', fillOpacity: 0.7 };
                        var highRiskStyle = { fillColor: '#00008B', weight: 1, opacity: 1, color: 'white', fillOpacity: 0.7 };
                        var criticalRiskStyle = { fillColor: '#8B0000', weight: 1, opacity: 1, color: 'white', fillOpacity: 0.7 };


                        if(id == '5yr'){




                            map.spin(true);
                            // Define the color classification symbology
                            const shapefileURL = '../assets/kml/fhm/Cauayan FH 5YR RRP.zip';
                            // const classification = {
                            //     value: 'value',
                            //     color: {
                            //         ramp: ['green', 'yellow', 'red']
                            //     },
                            //     label: '{value}'
                            // };
                            // Apply the symbology to the shapefile layer
                            // map.eachLayer(shapefileURL => {
                            // if (shapefileURL instanceof L.GeoJSON) {
                            //     shapefileURL.setStyle(classification).addTo(map);
                            // }
                            // });
                            // Load the shapefile
                            // L.shapefile(shapefileURL).addTo(map).eachLayer(layer => {
                            // if (layer instanceof L.GeoJSON) {
                            //     layer.setStyle(classification);
                            // }
                            // });
                            // Load the shapefile
                            // L.shapefile(shapefileURL).addTo(map).eachLayer(layer => {
                            // if (layer instanceof L.GeoJSON) {
                            //     // Define the color classification symbology
                            //     const classification = {
                            //     color: {
                            //         ramp: ['green', 'yellow', 'red']
                            //     }
                            //     };

                            //     // Apply the symbology to the shapefile layer
                            //     layer.setStyle(classification);
                            // }
                            // });


                            // Add a GeoJSON layer to the map
                            // const shapefileURL = '../assets/kml/fhm/Cauayan FH 5YR RRP.zip';
                            // $.ajax({
                            // url: shapefileURL,
                            // dataType: 'json',
                            // success: function(data) {
                            //     // Create a GeoJSON layer from the data
                            //     const geojsonLayer = L.geoJSON(data, {
                            //     style: function(feature) {
                            //         // Classify the feature based on its value and assign a color
                            //         switch (feature.properties.value) {
                            //         case 0:
                            //             return {color: 'white', outerLineColor: 'transparent', outerLineWeight: 1, outerLineType: 'solid'};
                            //         case 1:
                            //             return {color: 'yellow', outerLineColor: 'transparent', outerLineWeight: 1, outerLineType: 'solid'};
                            //         case 2:
                            //             return {color: 'orange', outerLineColor: 'transparent', outerLineWeight: 1, outerLineType: 'solid'};
                            //         case 3:
                            //             return {color: 'red', outerLineColor: 'transparent', outerLineWeight: 1, outerLineType: 'solid'};
                            //         }
                            //     },
                            //     onEachFeature: function(feature, layer) {
                            //         // Set the label for the feature
                            //         layer.bindLabel(feature.properties.label, { noHide: true });
                            //     }
                            //     });
                            //     geojsonLayer.addTo(map);
                            // }
                            // });
                            
  
  
  



  

  















                                    // var kmlLayer = L.layerGroup().addTo(map);

                            // // Function to fetch and parse shapefile
                            // function fetchAndParseShapefile(url) {
                            //     return fetch(url)
                            //         .then(response => response.arrayBuffer())
                            //         .then(buffer => shp(buffer));
                            // }

                            // // Style function based on feature properties
                            // function style(feature) {
                            //     var value = feature.properties.value; // Adjust based on your attribute name
                            //     return {
                            //         fillColor: getColor(value),
                            //         weight: 1,
                            //         opacity: 1,
                            //         color: 'white',
                            //         fillOpacity: 0.7
                            //     };
                            // }

                            // // Define a function to get color based on attribute value
                            // function getColor(value) {
                            //     // Define your color ranges or breaks here based on your classification method
                            //     console.log(value);
                            //     return value > 1 ? '#800026' :
                            //         value > 2  ? '#BD0026' :
                            //         value > 3  ? 'green' :
                            //         value > 4  ? 'red' :
                            //                         'orange';
                            // }

                            // // Fetch and parse shapefile, then add to map as GeoJSON with classification symbology
                            // fetchAndParseShapefile('../assets/kml/fhm/Cauayan FH 5YR RRP.zip')
                            //     .then(geojson => {
                            //         L.geoJSON(geojson, {
                            //             style: style
                            //         }).addTo(map);
                            //         map.spin(false);
                            //     })
                            //     .catch(error => {
                            //         console.error('Error loading shapefile:', error);
                            //         map.spin(false);
                            //     });


                            //     var overlayLayers ={
                            //         label: 'Flood Hazard Map',
                            //         children: [{
                            //             id: '5yrr',
                            //             label: 'KML Layer',
                            //             layer: kmlLayer
                            //         }]

                            //     };
                        }

                        




                        

                        //---------------------------------------------------
                        


                        
                        
                        

                        var baseTree = {
                            label: 'Base Layers',
                            children: [
                                {
                                    label: 'World &#x1f5fa;',
                                    children: [
                                        { label: 'OpenStreetMap', layer: tiles },
                                        { label: 'OpenStreetMap.HOT', layer: osmHOT },
                                        { label: 'World Imagery', layer: world_imagry },
                                        { label: 'World Topo', layer: world_topo },
                                        // { label: 'openTopoMap', layer: openTopoMap },
                                        // { label: 'World Imagery', layer: world_imagry },
                                        /* ... */
                                    ]
                                },
                            ]
                            };
                            
                            var otherlayers= {
                                // label: 'Other Layers',
                                // selectAllCheckbox: false,
                                label: 'Other Layers',
                                collapsed: true,
                                selectAllCheckbox: false,
                                children: [
                                    { label: 'Buildings CCC Bus station', layer: Buildingkml},
                                    { label: 'Isabela Boundary', layer: isabelakml},
                                    { label: 'Cauayan Boundary', layer: cauayankml},
                                    /* ... */
                                ]
                
                                
                            };


                            var layerControl = L.control.layers.tree(baseTree,[ otherlayers],{
                                namedToggle: true,
                                collapsed: false,
                            }).addTo(map);














                            // checkbox eventlistener------------
                            document.addEventListener('change', function(event) {
                                var checkbox = event.target;
                                if (checkbox.type === 'checkbox' && checkbox.checked) {
                                    // console.log('Checkbox checked:', checkbox.id  ); // Log the name of the checked checkbox
                                }
                            });


                        //-------------------------------------end


                        //---------------------loading layer-------------------------------------


                        // Show the spinner when the page is loading
                        map.spin(true);

                        // Stop the spinner when the page has finished loading
                        window.addEventListener('load', function () {
                            map.spin(false);
                        });
                        //----------------------------------------------------------------


            </script>
            {{-- <script type="text/javascript" src="https://edihasaj.github.io/leaflet-coord-projection/coord-projection.js"></script> --}}
    
            <script type="text/javascript">
                let kosovarefCrs = new L.Proj.CRS('EPSG:4326');
        

                
                new L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                 attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>',
                   label: 'OpenStreetMap',
                  minZoom: 2,
                }).addTo(map);
        
            L.control.coordProjection({
                    crs: kosovarefCrs,
                }).addTo(map);
            </script>
        </div>
    </body>
</html>
