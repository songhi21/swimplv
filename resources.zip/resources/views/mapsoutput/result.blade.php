@extends('layouts.mapsoutputresult')



@section('content')
<div id="map2" ></div>
<div class="navspaces2"></div>

<div class="container">
    <input type="hidden" id="hiddenId" value="{{ $id }}">
    <br>
    <br>
    <div id="arrayContainer">
        <!-- Array content will be displayed here -->
    </div>
</div>
@endsection